@file:Suppress("DEPRECATION")

package com.riconelson.cyclocomp.ui.map

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.preference.PreferenceManager
import android.view.MotionEvent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import com.riconelson.cyclocomp.R
import com.riconelson.cyclocomp.core.navigation.GeoPoint
import com.riconelson.cyclocomp.core.navigation.GpxRoute
import com.riconelson.cyclocomp.core.navigation.NavigationStatus
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint as OsmGeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import java.io.File

@SuppressLint("ClickableViewAccessibility")
@Composable
fun MapViewComposable(
    modifier: Modifier = Modifier,
    currentLocation: GeoPoint?,
    recordedPoints: List<GeoPoint> = emptyList(),
    activeRoute: GpxRoute? = null,
    navigationStatus: NavigationStatus? = null,
    showControls: Boolean = true,
    showTurnGuidance: Boolean = true,
    onDestinationLongPress: ((GeoPoint) -> Unit)? = null,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var isFollowingLocation by remember { mutableStateOf(true) }
    var hasCenteredOnLocation by remember { mutableStateOf(false) }
    var mapViewInstance by remember { mutableStateOf<MapView?>(null) }
    val destinationLongPress by rememberUpdatedState(onDestinationLongPress)

    val primaryColor = MaterialTheme.colorScheme.primary.toArgb()

    // osmdroid reads its configuration while the MapView is created.
    // Configure internal cache paths to avoid permission issues and Logcat errors on Android 10+ (Scoped Storage).
    remember(context) {
        val basePath = File(context.cacheDir, "osmdroid")
        val tileCache = File(basePath, "tiles")
        if (!basePath.exists()) basePath.mkdirs()
        if (!tileCache.exists()) tileCache.mkdirs()

        val config = Configuration.getInstance()
        config.userAgentValue = context.packageName
        config.osmdroidBasePath = basePath
        config.osmdroidTileCache = tileCache
        config.load(context, PreferenceManager.getDefaultSharedPreferences(context))
        true
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapViewInstance?.onResume()
                Lifecycle.Event.ON_PAUSE -> mapViewInstance?.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapViewInstance?.onDetach()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setUseDataConnection(true)
                    setMultiTouchControls(true)
                    isTilesScaledToDpi = true
                    minZoomLevel = 4.0
                    maxZoomLevel = 20.0
                    zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
                    controller.setZoom(16.0)
                    // Avoid opening on Null Island (a featureless blue ocean) before GPS arrives.
                    controller.setCenter(OsmGeoPoint(-6.2, 106.8166))
                    onResume()

                    setOnTouchListener { v, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_POINTER_DOWN -> {
                                isFollowingLocation = false
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                            }
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                v.parent?.requestDisallowInterceptTouchEvent(false)
                            }
                        }
                        false
                    }

                    // Touch gesture listener to pause auto-follow when user manually scrolls or pans
                    overlays.add(object : Overlay() {
                        override fun onTouchEvent(event: MotionEvent?, mapView: MapView?): Boolean {
                            if (event?.action == MotionEvent.ACTION_DOWN || event?.action == MotionEvent.ACTION_MOVE) {
                                isFollowingLocation = false
                            }
                            return false
                        }
                    })
                    overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                        override fun singleTapConfirmedHelper(point: OsmGeoPoint): Boolean = false

                        override fun longPressHelper(point: OsmGeoPoint): Boolean {
                            isFollowingLocation = false
                            destinationLongPress(GeoPoint(point.latitude, point.longitude))
                            return true
                        }
                    }))

                    mapViewInstance = this
                }
            },
            update = { mapView ->
                // Preserve the gesture and long-press overlays; replace visual layers only.
                while (mapView.overlays.size > 2) {
                    val overlay = mapView.overlays.removeAt(2)
                    runCatching { overlay.onDetach(mapView) }
                }

                // 1. Draw Active GPX Route Overlay (Cyan/Primary line)
                activeRoute?.let { route ->
                    if (route.points.isNotEmpty()) {
                        val routePolyline = Polyline(mapView).apply {
                            outlinePaint.color = primaryColor
                            outlinePaint.strokeWidth = 12f
                            outlinePaint.strokeCap = Paint.Cap.ROUND
                            setPoints(route.points.map { OsmGeoPoint(it.latitude, it.longitude) })
                        }
                        mapView.overlays.add(routePolyline)

                        // Start Marker
                        val startPoint = route.points.first()
                        val startMarker = Marker(mapView).apply {
                            position = OsmGeoPoint(startPoint.latitude, startPoint.longitude)
                            title = "Start"
                            icon = ContextCompat.getDrawable(context, R.drawable.ic_map_start_pin)
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        }
                        mapView.overlays.add(startMarker)

                        // Finish Marker
                        val endPoint = route.points.last()
                        val endMarker = Marker(mapView).apply {
                            position = OsmGeoPoint(endPoint.latitude, endPoint.longitude)
                            title = "Finish"
                            icon = ContextCompat.getDrawable(context, R.drawable.ic_map_finish_pin)
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        }
                        mapView.overlays.add(endMarker)
                    }
                }

                // 2. Draw Live Recorded Ride Track Overlay (Bright Green line)
                if (recordedPoints.size >= 2) {
                    val trackPolyline = Polyline(mapView).apply {
                        outlinePaint.color = AndroidColor.parseColor("#00E676")
                        outlinePaint.strokeWidth = 14f
                        outlinePaint.strokeCap = Paint.Cap.ROUND
                        setPoints(recordedPoints.map { OsmGeoPoint(it.latitude, it.longitude) })
                    }
                    mapView.overlays.add(trackPolyline)
                }

                // 3. Draw Current Rider Location Marker
                currentLocation?.let { loc ->
                    val osmLoc = OsmGeoPoint(loc.latitude, loc.longitude)
                    val locationMarker = Marker(mapView).apply {
                        position = osmLoc
                        title = "You are here"
                        icon = ContextCompat.getDrawable(context, R.drawable.ic_user_location_dot)
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    }
                    mapView.overlays.add(locationMarker)

                    if (isFollowingLocation) {
                        if (hasCenteredOnLocation) mapView.controller.animateTo(osmLoc)
                        else {
                            mapView.controller.setCenter(osmLoc)
                            hasCenteredOnLocation = true
                        }
                    }
                }

                mapView.invalidate()
            },
        )

        Text(
            "© OpenStreetMap contributors",
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
        )

        // Fit Route Bounds on Active Route Load
        LaunchedEffect(activeRoute) {
            val route = activeRoute
            val map = mapViewInstance
            if (route != null && route.points.isNotEmpty() && map != null) {
                val osmPoints = route.points.map { OsmGeoPoint(it.latitude, it.longitude) }
                val box = BoundingBox.fromGeoPoints(osmPoints)
                map.post {
                    map.zoomToBoundingBox(box, true, 80)
                }
            }
        }

        if (currentLocation == null && activeRoute == null) {
            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f)),
            ) {
                Text(
                    "Waiting for GPS to center the map",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }

        // Floating Turn Guidance Overlay Card
        if (showTurnGuidance && activeRoute != null && navigationStatus != null) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (navigationStatus.isOffCourse) MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.primaryContainer,
                ),
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (navigationStatus.isOffCourse) {
                        Text(
                            text = "Off Course · ${navigationStatus.distanceToRouteMeters.toInt()} m from route",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    } else {
                        val nextTurn = navigationStatus.nextTurnCue
                        val distToTurn = navigationStatus.distanceToNextTurnMeters?.toInt()
                        Text(
                            text = when {
                                nextTurn != null && distToTurn != null -> "In ${distToTurn} m: ${nextTurn.turnType.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}"
                                else -> "Following ${activeRoute.name ?: "Course"}"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                        if (nextTurn != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = nextTurn.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                    }
                }
            }
        }

        // Map Control Floating Buttons (Recenter / Zoom)
        if (showControls) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                SmallFloatingActionButton(
                    onClick = { mapViewInstance?.controller?.zoomIn() },
                    shape = CircleShape,
                ) {
                    Text("+", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(8.dp))

                SmallFloatingActionButton(
                    onClick = { mapViewInstance?.controller?.zoomOut() },
                    shape = CircleShape,
                ) {
                    Text("-", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (activeRoute != null && activeRoute.points.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    SmallFloatingActionButton(
                        onClick = {
                            val osmPoints = activeRoute.points.map { OsmGeoPoint(it.latitude, it.longitude) }
                            val box = BoundingBox.fromGeoPoints(osmPoints)
                            mapViewInstance?.zoomToBoundingBox(box, true, 80)
                        },
                        shape = CircleShape,
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    ) {
                        Text("⤢", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(8.dp))

                FloatingActionButton(
                    onClick = {
                        isFollowingLocation = true
                        currentLocation?.let { loc ->
                            mapViewInstance?.controller?.animateTo(OsmGeoPoint(loc.latitude, loc.longitude))
                        }
                    },
                    containerColor = if (isFollowingLocation) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (isFollowingLocation) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    shape = CircleShape,
                ) {
                    Text("⌖", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
