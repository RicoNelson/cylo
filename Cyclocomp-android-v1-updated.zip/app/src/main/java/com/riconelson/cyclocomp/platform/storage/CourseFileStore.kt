package com.riconelson.cyclocomp.platform.storage

import android.content.Context
import com.riconelson.cyclocomp.core.navigation.GpxParser
import com.riconelson.cyclocomp.core.navigation.GpxRoute
import java.io.File
import java.nio.file.Files
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.StandardCopyOption

/** Keeps the selected course locally so a rider does not need to import it again after restarting. */
class CourseFileStore(
    filesDir: File,
) {
    constructor(context: Context) : this(context.filesDir)

    private val courseFile = File(filesDir, "selected-course.gpx")

    fun load(): GpxRoute? {
        if (!courseFile.exists() || (courseFile.length() == 0L)) {
            return runCatching { save(SEED_GPX) }.getOrNull()
        }
        return runCatching { GpxParser.parse(courseFile.readText()) }.getOrNull()
    }

    fun resetToSeedRoute(): GpxRoute {
        return save(SEED_GPX)
    }

    fun save(gpx: String): GpxRoute {
        val route = GpxParser.parse(gpx)
        val temporary = File(courseFile.parentFile, ".selected-course.tmp")
        temporary.writeText(gpx)
        try {
            Files.move(
                temporary.toPath(),
                courseFile.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temporary.toPath(), courseFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        return route
    }

    fun clear() {
        if (courseFile.exists()) check(courseFile.delete()) { "Cyclocomp could not remove this course" }
    }

    companion object {
        val SEED_GPX = """
            <?xml version="1.0" encoding="UTF-8"?>
            <gpx version="1.1" creator="Cyclocomp Seed Route"
                 xmlns="http://www.topografix.com/GPX/1/1"
                 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
              <metadata>
                <name>Central Park Cycling Loop</name>
                <desc>Public sample cycling route for testing navigation, turn cues, and off-course detection.</desc>
                <time>2026-05-10T08:00:00Z</time>
              </metadata>
              <wpt lat="37.7749" lon="-122.4194">
                <name>Start / Finish Hub</name>
                <desc>Main clubhouse and water refill station</desc>
              </wpt>
              <wpt lat="37.7771" lon="-122.4150">
                <name>Summit Viewpoint</name>
                <desc>Highest elevation on the loop</desc>
              </wpt>
              <wpt lat="37.7772" lon="-122.4185">
                <name>Cafe Stop</name>
                <desc>Mid-ride espresso and snacks</desc>
              </wpt>
              <trk>
                <name>Central Park Cycling Loop</name>
                <type>Cycling</type>
                <trkseg>
                  <trkpt lat="37.7749" lon="-122.4194"><ele>15.0</ele></trkpt>
                  <trkpt lat="37.7758" lon="-122.4194"><ele>16.5</ele></trkpt>
                  <trkpt lat="37.7758" lon="-122.4160"><ele>19.0</ele></trkpt>
                  <trkpt lat="37.7771" lon="-122.4150"><ele>24.5</ele></trkpt>
                  <trkpt lat="37.7771" lon="-122.4180"><ele>21.0</ele></trkpt>
                  <trkpt lat="37.7760" lon="-122.4194"><ele>17.5</ele></trkpt>
                  <trkpt lat="37.7749" lon="-122.4194"><ele>15.0</ele></trkpt>
                </trkseg>
              </trk>
            </gpx>
        """.trimIndent()
    }
}

