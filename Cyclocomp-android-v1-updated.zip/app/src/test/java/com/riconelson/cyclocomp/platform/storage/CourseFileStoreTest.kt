package com.riconelson.cyclocomp.platform.storage

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class CourseFileStoreTest {
    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var store: CourseFileStore
    private lateinit var targetDir: File

    @Before
    fun setUp() {
        targetDir = tempFolder.newFolder("files")
        store = CourseFileStore(targetDir)
    }

    @Test
    fun `load automatically seeds default GPX when no course file exists`() {
        val route = store.load()
        assertNotNull(route)
        assertEquals("Central Park Cycling Loop", route?.name)
        assertEquals(7, route?.points?.size)
    }

    @Test
    fun `save persists new GPX and clear removes it`() {
        val customGpx = """
            <gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1">
              <trk><name>Custom Trail</name><trkseg>
                <trkpt lat="1.0" lon="1.0"/>
                <trkpt lat="2.0" lon="2.0"/>
              </trkseg></trk>
            </gpx>
        """.trimIndent()

        val savedRoute = store.save(customGpx)
        assertEquals("Custom Trail", savedRoute.name)

        val loadedRoute = store.load()
        assertEquals("Custom Trail", loadedRoute?.name)

        store.clear()
        val file = File(targetDir, "selected-course.gpx")
        assertEquals(false, file.exists())
    }

    @Test
    fun `resetToSeedRoute overwrites active course with default seed GPX`() {
        val customGpx = """
            <gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1">
              <trk><name>Old Course</name><trkseg>
                <trkpt lat="1.0" lon="1.0"/>
                <trkpt lat="2.0" lon="2.0"/>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        store.save(customGpx)

        val resetRoute = store.resetToSeedRoute()
        assertEquals("Central Park Cycling Loop", resetRoute.name)

        val loadedRoute = store.load()
        assertEquals("Central Park Cycling Loop", loadedRoute?.name)
    }
}
