package com.riconelson.cyclocomp.core.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GpxNavigationTest {
    @Test
    fun `parser reads track points route name and waypoints`() {
        val route = GpxParser.parse(
            """
            <gpx xmlns="http://www.topografix.com/GPX/1/1">
              <trk><name>Morning loop</name><trkseg>
                <trkpt lat="-6.1754" lon="106.8272"><ele>12.5</ele></trkpt>
                <trkpt lat="-6.1750" lon="106.8280"/>
              </trkseg></trk>
              <wpt lat="-6.1751" lon="106.8276"><name>Water</name><desc>Refill bottle</desc></wpt>
            </gpx>
            """.trimIndent(),
        )

        assertEquals("Morning loop", route.name)
        assertEquals(2, route.points.size)
        assertEquals(12.5, route.points.first().elevationMeters!!, 0.001)
        assertEquals("Water", route.waypoints.single().name)
    }

    @Test
    fun `navigation reports nearest route point and off course state`() {
        val route = GpxRoute(
            name = null,
            points = listOf(GeoPoint(-6.1754, 106.8272), GeoPoint(-6.1754, 106.8282)),
            waypoints = emptyList(),
        )

        val onCourse = RouteNavigation.evaluate(route, GeoPoint(-6.1754, 106.82725), 50.0)
        val offCourse = RouteNavigation.evaluate(route, GeoPoint(-6.1740, 106.8272), 50.0)

        assertEquals(0, onCourse.nearestPointIndex)
        assertFalse(onCourse.isOffCourse)
        assertTrue(onCourse.distanceToNextPointMeters!! > 0)
        assertTrue(offCourse.isOffCourse)
    }

    @Test
    fun `navigation measures distance to a segment rather than only a route point`() {
        val route = GpxRoute(
            name = null,
            points = listOf(GeoPoint(0.0, 0.0), GeoPoint(0.0, 0.002)),
            waypoints = emptyList(),
        )

        val status = RouteNavigation.evaluate(route, GeoPoint(0.0, 0.001), 20.0)

        assertFalse(status.isOffCourse)
        assertTrue(status.distanceToRouteMeters < 0.1)
    }
}
