package com.riconelson.cyclocomp.core.ride

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RideTrackerTest {
    private val tracker = RideTracker(RideTrackerConfig(autoPauseAfterMillis = 8_000))

    @Test
    fun `counts a moving GPS segment with haversine distance`() {
        val started = tracker.start(0)
        val first = tracker.onLocation(started, point(0, -6.2000, 106.8166))
        val moved = tracker.onLocation(first, point(1_000, -6.2000, 106.8176))

        assertEquals(110.5, moved.metrics.distanceMeters, 2.0)
        assertEquals(1_000, moved.metrics.movingTimeMillis)
        assertEquals(1_000, moved.metrics.elapsedTimeMillis)
    }

    @Test
    fun `auto pauses after stationary threshold and clears when moving`() {
        var state = tracker.onLocation(tracker.start(0), point(0, -6.2, 106.8))
        state = tracker.onLocation(state, point(5_000, -6.2, 106.8, speed = 0f))
        assertFalse(state.metrics.autoPaused)

        state = tracker.onLocation(state, point(8_000, -6.2, 106.8, speed = 0f))
        assertTrue(state.metrics.autoPaused)

        state = tracker.onLocation(state, point(9_000, -6.2, 106.8001))
        assertFalse(state.metrics.autoPaused)
        assertEquals(1_000, state.metrics.movingTimeMillis)
    }

    @Test
    fun `ignores an inaccurate point`() {
        val state = tracker.start(0)
        val ignored = tracker.onLocation(state, point(1_000, -6.2, 106.8, accuracy = 75f))

        assertNull(ignored.lastAcceptedPoint)
    }

    private fun point(
        time: Long,
        latitude: Double,
        longitude: Double,
        accuracy: Float = 5f,
        speed: Float? = null,
    ) = RidePoint(time, latitude, longitude, accuracyMeters = accuracy, reportedSpeedMetersPerSecond = speed)
}
