package com.riconelson.cyclocomp.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.riconelson.cyclocomp.core.navigation.GeoPoint
import com.riconelson.cyclocomp.core.navigation.GpxParser
import com.riconelson.cyclocomp.core.navigation.GpxRoute
import com.riconelson.cyclocomp.core.navigation.NavigationStatus
import com.riconelson.cyclocomp.core.navigation.RouteNavigation
import com.riconelson.cyclocomp.core.ride.RideState
import com.riconelson.cyclocomp.core.ride.RideStatus
import com.riconelson.cyclocomp.platform.location.RideTrackingService
import com.riconelson.cyclocomp.platform.sensors.BluetoothSensorScanner
import com.riconelson.cyclocomp.platform.storage.RideFileStore
import com.riconelson.cyclocomp.platform.storage.SavedRideFile
import kotlinx.coroutines.flow.collect

private val OutdoorColorScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFFB8C4FF),
    onPrimary = Color(0xFF10255E),
    primaryContainer = Color(0xFF29457E),
    onPrimaryContainer = Color(0xFFDEE1FF),
    secondary = Color(0xFFBEC6DC),
    onSecondary = Color(0xFF283044),
    surface = Color(0xFF111318),
    onSurface = Color(0xFFE2E2E9),
    surfaceVariant = Color(0xFF252931),
    onSurfaceVariant = Color(0xFFC5C6D0),
    outline = Color(0xFF8F909A),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
)

data class LiveRideUiState(
    val speedKmh: Double = 0.0,
    val distanceKm: Double = 0.0,
    val movingSeconds: Long = 0,
    val gpsAccuracyMeters: Float? = null,
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
)

private enum class AppDestination(val label: String, val symbol: String) {
    Ride("Ride", "●"),
    Routes("Routes", "⌖"),
    History("History", "◷"),
    Devices("Devices", "⌁"),
}

@Composable
fun CyclocompApp() {
    val context = LocalContext.current
    val applicationContext = context.applicationContext
    var destination by remember { mutableStateOf(AppDestination.Ride) }
    val service = rememberRideService()
    val sensorScanner = remember(applicationContext) { BluetoothSensorScanner(applicationContext) }
    val sensors by sensorScanner.sensors.collectAsState()
    val isScanning by sensorScanner.isScanning.collectAsState()
    var rideState by remember { mutableStateOf(RideState()) }
    var activeRoute by remember { mutableStateOf<GpxRoute?>(null) }
    var routeError by remember { mutableStateOf<String?>(null) }
    var savedRides by remember { mutableStateOf<List<SavedRideFile>>(emptyList()) }
    val startRide = {
        ContextCompat.startForegroundService(context, RideTrackingService.startIntent(context))
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRide()
    }
    val bluetoothPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) sensorScanner.start()
    }
    val gpxImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { GpxParser.parse(it.readText()) }
                    ?: error("Cyclocomp could not read that file")
            }.onSuccess { route ->
                activeRoute = route
                routeError = null
            }.onFailure { error ->
                routeError = error.message ?: "That file is not a usable GPX route"
            }
        }
    }

    LaunchedEffect(service) {
        service?.rideState?.collect { rideState = it }
    }
    DisposableEffect(sensorScanner) {
        onDispose { sensorScanner.close() }
    }
    LaunchedEffect(destination) {
        if (destination == AppDestination.History) savedRides = RideFileStore(context).listRideFiles()
    }
    val navigationStatus = activeRoute?.let { route ->
        rideState.lastAcceptedPoint?.let { point ->
            RouteNavigation.evaluate(route, GeoPoint(point.latitude, point.longitude))
        }
    }

    MaterialTheme(colorScheme = OutdoorColorScheme) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                when (destination) {
                    AppDestination.Ride -> RideScreen(
                        state = rideState.toUiState(),
                        routeName = activeRoute?.name,
                        navigationStatus = navigationStatus,
                        onStart = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                                startRide()
                            } else {
                                locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            }
                        },
                        onPause = { context.startService(RideTrackingService.pauseIntent(context)) },
                        onResume = { ContextCompat.startForegroundService(context, RideTrackingService.resumeIntent(context)) },
                        onEnd = { context.startService(RideTrackingService.stopIntent(context)) },
                    )
                    AppDestination.Routes -> RoutesScreen(
                        route = activeRoute,
                        errorMessage = routeError,
                        onImport = {
                            gpxImport.launch(arrayOf("application/gpx+xml", "application/xml", "text/xml", "application/octet-stream"))
                        },
                        onClear = {
                            activeRoute = null
                            routeError = null
                        },
                    )
                    AppDestination.History -> HistoryScreen(
                        rides = savedRides,
                        onRefresh = { savedRides = RideFileStore(context).listRideFiles() },
                    )
                    AppDestination.Devices -> DevicesScreen(
                        sensors = sensors,
                        isScanning = isScanning,
                        onScan = {
                            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                            } else {
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                            }
                            if (permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) {
                                sensorScanner.start()
                            } else {
                                bluetoothPermission.launch(permissions)
                            }
                        },
                    )
                }

                NavigationBar {
                    AppDestination.entries.forEach { item ->
                        NavigationBarItem(
                            selected = item == destination,
                            onClick = { destination = item },
                            icon = { Text(item.symbol, fontSize = 20.sp) },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberRideService(): RideTrackingService? {
    val context = LocalContext.current
    var service by remember { mutableStateOf<RideTrackingService?>(null) }
    val connection = remember {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                service = (binder as RideTrackingService.LocalBinder).service()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                service = null
            }
        }
    }
    DisposableEffect(context, connection) {
        val isBound = context.bindService(Intent(context, RideTrackingService::class.java), connection, Context.BIND_AUTO_CREATE)
        onDispose { if (isBound) context.unbindService(connection) }
    }
    return service
}

private fun RideState.toUiState(): LiveRideUiState = LiveRideUiState(
    speedKmh = metrics.currentSpeedMetersPerSecond * 3.6,
    distanceKm = metrics.distanceMeters / 1_000.0,
    movingSeconds = metrics.movingTimeMillis / 1_000,
    gpsAccuracyMeters = lastAcceptedPoint?.accuracyMeters,
    isRecording = status == RideStatus.RECORDING,
    isPaused = status == RideStatus.PAUSED,
)

@Composable
fun RideScreen(
    state: LiveRideUiState,
    routeName: String?,
    navigationStatus: NavigationStatus?,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onEnd: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Ride", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Text(
            text = gpsLabel(state.gpsAccuracyMeters),
            color = if (state.gpsAccuracyMeters == null) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF8DE8AF),
            style = MaterialTheme.typography.labelLarge,
        )

        RideMetric(
            label = "Speed",
            value = "%.1f".format(state.speedKmh),
            unit = "km/h",
            emphasized = true,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RideMetric(
                label = "Distance",
                value = "%.2f".format(state.distanceKm),
                unit = "km",
                modifier = Modifier.weight(1f),
            )
            RideMetric(
                label = "Moving time",
                value = formatDuration(state.movingSeconds),
                unit = "",
                modifier = Modifier.weight(1f),
            )
        }

        if (routeName != null) {
            NavigationCard(routeName, navigationStatus)
        }

        Spacer(Modifier.weight(1f))

        when {
            !state.isRecording -> RideButton("Start ride", onStart)
            state.isPaused -> {
                RideButton("Resume ride", onResume)
                EndButton(onEnd)
            }
            else -> {
                RideButton("Pause ride", onPause, primary = false)
                EndButton(onEnd)
            }
        }
    }
}

@Composable
private fun NavigationCard(routeName: String, status: NavigationStatus?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(routeName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                text = when {
                    status == null -> "Waiting for GPS to start course guidance"
                    status.isOffCourse -> "Off course · ${status.distanceToRouteMeters.toInt()} m from route"
                    else -> "On course · ${status.distanceToNextPointMeters?.toInt() ?: 0} m to next point"
                },
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun RideMetric(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier,
    emphasized: Boolean = false,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    style = if (emphasized) MaterialTheme.typography.displayLarge else MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Medium,
                )
                if (unit.isNotBlank()) {
                    Spacer(Modifier.width(6.dp))
                    Text(unit, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun RideButton(label: String, onClick: () -> Unit, primary: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(64.dp),
        colors = if (primary) ButtonDefaults.buttonColors() else ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        ),
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EndButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
        ),
    ) {
        Text("End ride", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FeaturePlaceholder(title: String, description: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Text(
            description,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
        )
    }
}

private fun gpsLabel(accuracyMeters: Float?): String = when {
    accuracyMeters == null -> "Waiting for GPS"
    accuracyMeters <= 10f -> "GPS ready · ±${accuracyMeters.toInt()} m"
    else -> "GPS weak · ±${accuracyMeters.toInt()} m"
}

private fun formatDuration(seconds: Long): String {
    val hours = seconds / 3_600
    val minutes = (seconds % 3_600) / 60
    val remainingSeconds = seconds % 60
    return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, remainingSeconds)
    else "%02d:%02d".format(minutes, remainingSeconds)
}
