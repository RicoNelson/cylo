package com.riconelson.cyclocomp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.riconelson.cyclocomp.platform.sensors.DiscoveredSensor
import com.riconelson.cyclocomp.platform.sensors.SensorType

@Composable
fun DevicesScreen(
    sensors: List<DiscoveredSensor>,
    isScanning: Boolean,
    onScan: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Devices", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    if (isScanning) "Searching for nearby sensors…" else "BLE sensors · Android 11 also needs Location enabled",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Button(onClick = onScan, enabled = !isScanning) {
                Text(if (isScanning) "Scanning" else "Scan")
            }
        }

        if (sensors.isEmpty()) {
            Spacer(Modifier.weight(1f))
            Text(
                if (isScanning) "Keep your sensor awake and nearby." else "No sensor found yet.",
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.weight(1f))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(sensors, key = DiscoveredSensor::id) { sensor ->
                    SensorCard(sensor)
                }
            }
        }
    }
}

@Composable
private fun SensorCard(sensor: DiscoveredSensor) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                sensor.name ?: "Cycling sensor",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                sensor.types.sortedBy(SensorType::ordinal).joinToString(" · ") { it.label() },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Signal ${sensor.rssi} dBm",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

private fun SensorType.label(): String = when (this) {
    SensorType.HEART_RATE -> "Heart rate"
    SensorType.SPEED_CADENCE -> "Speed & cadence"
    SensorType.POWER -> "Power"
}
