package com.riconelson.cyclocomp.platform.storage

import android.content.Context
import com.riconelson.cyclocomp.core.ride.RidePoint
import com.riconelson.cyclocomp.core.ride.RideState
import com.riconelson.cyclocomp.core.ride.RideStatus
import java.io.File
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.time.Instant

data class SavedRideFile(
    val file: File,
    val recordedAtMillis: Long,
    val byteSize: Long,
)

/** Writes completed rides privately to the app's files directory as portable GPX. */
class RideFileStore(context: Context) {
    // shortcut: completed rides are GPX files only; add Room when indexed history and charts are implemented.
    private val directory = File(context.filesDir, DIRECTORY_NAME)

    fun save(state: RideState, points: List<RidePoint>): SavedRideFile {
        require(state.status == RideStatus.FINISHED) { "Only completed rides can be saved" }
        require(points.isNotEmpty()) { "A ride needs at least one GPS point" }
        if (!directory.exists()) check(directory.mkdirs()) { "Unable to create ride storage" }

        val recordedAt = state.startedAtMillis ?: points.first().timestampMillis
        val output = File(directory, "ride-$recordedAt.gpx")
        val temporary = File(directory, ".ride-$recordedAt.gpx.tmp")
        FileOutputStream(temporary).use { stream ->
            stream.write(gpx(points, recordedAt).toByteArray(Charsets.UTF_8))
            stream.fd.sync()
        }
        try {
            Files.move(
                temporary.toPath(),
                output.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: AtomicMoveNotSupportedException) {
            check(temporary.renameTo(output)) { "Unable to save ride" }
        }
        return SavedRideFile(output, recordedAt, output.length())
    }

    fun listRideFiles(): List<SavedRideFile> = directory
        .listFiles { file -> file.isFile && file.extension.equals("gpx", ignoreCase = true) }
        ?.map { file ->
            SavedRideFile(
                file = file,
                recordedAtMillis = file.nameWithoutExtension.removePrefix("ride-").toLongOrNull() ?: file.lastModified(),
                byteSize = file.length(),
            )
        }
        ?.sortedByDescending(SavedRideFile::recordedAtMillis)
        .orEmpty()

    private fun gpx(points: List<RidePoint>, recordedAt: Long): String = buildString {
        appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        appendLine("<gpx version=\"1.1\" creator=\"Cyclocomp\" xmlns=\"http://www.topografix.com/GPX/1/1\">")
        appendLine("  <metadata><time>${Instant.ofEpochMilli(recordedAt)}</time></metadata>")
        appendLine("  <trk><name>Cyclocomp ride</name><trkseg>")
        points.forEach { point ->
            append("    <trkpt lat=\"").append(point.latitude).append("\" lon=\"").append(point.longitude).appendLine("\">")
            point.altitudeMeters?.let { append("      <ele>").append(it).appendLine("</ele>") }
            append("      <time>").append(Instant.ofEpochMilli(point.timestampMillis)).appendLine("</time>")
            appendLine("    </trkpt>")
        }
        appendLine("  </trkseg></trk>")
        appendLine("</gpx>")
    }

    private companion object {
        const val DIRECTORY_NAME = "cyclocomp-rides"
    }
}
