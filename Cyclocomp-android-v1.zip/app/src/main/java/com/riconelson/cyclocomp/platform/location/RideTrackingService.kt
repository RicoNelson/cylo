package com.riconelson.cyclocomp.platform.location

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.riconelson.cyclocomp.MainActivity
import com.riconelson.cyclocomp.core.ride.RidePoint
import com.riconelson.cyclocomp.core.ride.RideState
import com.riconelson.cyclocomp.core.ride.RideStatus
import com.riconelson.cyclocomp.core.ride.RideTracker
import com.riconelson.cyclocomp.platform.storage.RideFileStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Owns GPS only during a user-started ride. Persistence remains outside this service.
 */
class RideTrackingService : Service() {
    private val binder = LocalBinder()
    private val locationManager by lazy { getSystemService(LocationManager::class.java) }
    private val rideFileStore by lazy { RideFileStore(this) }
    private val tracker = RideTracker()
    private val recordedPoints = mutableListOf<RidePoint>()
    private val _latestPoint = MutableStateFlow<RidePoint?>(null)
    private val _rideState = MutableStateFlow(RideState())

    val latestPoint: StateFlow<RidePoint?> = _latestPoint.asStateFlow()
    val rideState: StateFlow<RideState> = _rideState.asStateFlow()

    private val listener = LocationListener { location ->
        if (location.hasAccuracy()) {
            val point = RidePoint(
                timestampMillis = location.time,
                latitude = location.latitude,
                longitude = location.longitude,
                altitudeMeters = location.takeIf(Location::hasAltitude)?.altitude,
                accuracyMeters = location.accuracy,
                reportedSpeedMetersPerSecond = location.takeIf(Location::hasSpeed)?.speed,
            )
            _latestPoint.value = point
            val updatedState = tracker.onLocation(_rideState.value, point)
            if (updatedState.lastAcceptedPoint === point) recordedPoints += point
            _rideState.value = updatedState
        }
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = when (intent?.action) {
        ACTION_START -> {
            beginTracking()
            START_NOT_STICKY
        }
        ACTION_PAUSE -> {
            _rideState.value = tracker.pause(_rideState.value, System.currentTimeMillis())
            locationManager.removeUpdates(listener)
            stopForeground(STOP_FOREGROUND_REMOVE)
            START_NOT_STICKY
        }
        ACTION_RESUME -> {
            startForegroundCompat()
            _rideState.value = tracker.resume(_rideState.value, System.currentTimeMillis())
            requestUpdates()
            START_NOT_STICKY
        }
        ACTION_STOP -> {
            _rideState.value = tracker.end(_rideState.value, System.currentTimeMillis())
            locationManager.removeUpdates(listener)
            runCatching { rideFileStore.save(_rideState.value, recordedPoints.toList()) }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            START_NOT_STICKY
        }
        else -> START_NOT_STICKY
    }

    override fun onDestroy() {
        locationManager.removeUpdates(listener)
        super.onDestroy()
    }

    private fun beginTracking() {
        startForegroundCompat()
        if (!hasFineLocationPermission() || !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        _rideState.value = when (_rideState.value.status) {
            RideStatus.PAUSED -> tracker.resume(_rideState.value, System.currentTimeMillis())
            RideStatus.RECORDING -> _rideState.value
            else -> {
                recordedPoints.clear()
                tracker.start(System.currentTimeMillis())
            }
        }
        requestUpdates()
    }

    private fun requestUpdates() {
        if (!hasFineLocationPermission() || !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return
        locationManager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            GPS_INTERVAL_MILLIS,
            MINIMUM_DISTANCE_METERS,
            listener,
        )
    }

    private fun hasFineLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startForegroundCompat() {
        val notification = trackingNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun trackingNotification(): Notification {
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Ride tracking", NotificationManager.IMPORTANCE_LOW),
        )
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Cyclocomp is recording")
            .setContentText("GPS ride tracking is active")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    inner class LocalBinder : Binder() {
        fun service(): RideTrackingService = this@RideTrackingService
    }

    companion object {
        const val ACTION_START = "com.riconelson.cyclocomp.action.START_RIDE_TRACKING"
        const val ACTION_PAUSE = "com.riconelson.cyclocomp.action.PAUSE_RIDE_TRACKING"
        const val ACTION_RESUME = "com.riconelson.cyclocomp.action.RESUME_RIDE_TRACKING"
        const val ACTION_STOP = "com.riconelson.cyclocomp.action.STOP_RIDE_TRACKING"
        private const val CHANNEL_ID = "ride_tracking"
        private const val NOTIFICATION_ID = 1001
        private const val GPS_INTERVAL_MILLIS = 1_000L
        private const val MINIMUM_DISTANCE_METERS = 0f

        fun startIntent(context: Context): Intent = Intent(context, RideTrackingService::class.java).apply {
            action = ACTION_START
        }

        fun stopIntent(context: Context): Intent = Intent(context, RideTrackingService::class.java).apply {
            action = ACTION_STOP
        }

        fun pauseIntent(context: Context): Intent = Intent(context, RideTrackingService::class.java).apply {
            action = ACTION_PAUSE
        }

        fun resumeIntent(context: Context): Intent = Intent(context, RideTrackingService::class.java).apply {
            action = ACTION_RESUME
        }
    }
}
