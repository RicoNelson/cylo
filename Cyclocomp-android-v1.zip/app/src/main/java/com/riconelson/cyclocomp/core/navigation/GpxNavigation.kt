package com.riconelson.cyclocomp.core.navigation

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.StringReader
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class GeoPoint(
    val latitude: Double,
    val longitude: Double,
    val elevationMeters: Double? = null,
)

data class RouteWaypoint(
    val point: GeoPoint,
    val name: String? = null,
    val note: String? = null,
)

data class GpxRoute(
    val name: String?,
    val points: List<GeoPoint>,
    val waypoints: List<RouteWaypoint>,
)

data class NavigationStatus(
    val nearestPointIndex: Int,
    val distanceToRouteMeters: Double,
    val distanceToNextPointMeters: Double?,
    val isOffCourse: Boolean,
)

/** Minimal, local-only GPX import for following a recorded route. */
object GpxParser {
    fun parse(xml: String): GpxRoute {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            isExpandEntityReferences = false
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        }
        val document = factory.newDocumentBuilder().parse(org.xml.sax.InputSource(StringReader(xml)))
        val trackPoints = document.elementsNamed("trkpt").mapNotNull(::pointFrom)
        val routePoints = document.elementsNamed("rtept").mapNotNull(::pointFrom)
        val points = if (trackPoints.isNotEmpty()) trackPoints else routePoints
        require(points.size >= 2) { "GPX needs at least two track or route points" }

        val waypoints = document.elementsNamed("wpt").mapNotNull { element ->
            pointFrom(element)?.let { point ->
                RouteWaypoint(point, element.childText("name"), element.childText("desc"))
            }
        }
        val name = document.elementsNamed("trk").firstOrNull()?.childText("name")
            ?: document.elementsNamed("rte").firstOrNull()?.childText("name")
            ?: document.rootElement.childText("name")
        return GpxRoute(name, points, waypoints)
    }

    private fun pointFrom(element: Element): GeoPoint? {
        val latitude = element.getAttribute("lat").toDoubleOrNull() ?: return null
        val longitude = element.getAttribute("lon").toDoubleOrNull() ?: return null
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return null
        return GeoPoint(latitude, longitude, element.childText("ele")?.toDoubleOrNull())
    }

    private fun org.w3c.dom.Document.elementsNamed(name: String): List<Element> =
        allElements().filter { it.matchesName(name) }

    private fun org.w3c.dom.Document.allElements(): List<Element> {
        val found = mutableListOf<Element>()
        fun visit(node: Node) {
            if (node is Element) found += node
            for (index in 0 until node.childNodes.length) visit(node.childNodes.item(index))
        }
        visit(documentElement)
        return found
    }

    private fun Element.childText(name: String): String? =
        (0 until childNodes.length)
            .map { childNodes.item(it) }
            .filterIsInstance<Element>()
            .firstOrNull { it.matchesName(name) }
            ?.textContent
            ?.trim()
            ?.takeIf { it.isNotEmpty() }

    private fun Element.matchesName(name: String): Boolean = localName == name || nodeName.substringAfter(':') == name
    private val org.w3c.dom.Document.rootElement: Element get() = documentElement
}

object RouteNavigation {
    private const val EarthRadiusMeters = 6_371_000.0

    fun evaluate(
        route: GpxRoute,
        current: GeoPoint,
        offCourseThresholdMeters: Double = 50.0,
    ): NavigationStatus {
        require(offCourseThresholdMeters > 0) { "Off-course threshold must be positive" }
        val nearest = route.points.indices.minByOrNull { index -> distanceMeters(current, route.points[index]) }
            ?: error("Route has no points")
        val distanceToRoute = route.points
            .zipWithNext()
            .minOfOrNull { (start, end) -> distanceToSegmentMeters(current, start, end) }
            ?: distanceMeters(current, route.points[nearest])
        val next = route.points.getOrNull(nearest + 1)
        return NavigationStatus(
            nearestPointIndex = nearest,
            distanceToRouteMeters = distanceToRoute,
            distanceToNextPointMeters = next?.let { distanceMeters(current, it) },
            isOffCourse = distanceToRoute > offCourseThresholdMeters,
        )
    }

    fun distanceMeters(from: GeoPoint, to: GeoPoint): Double {
        val latitudeDelta = Math.toRadians(to.latitude - from.latitude)
        val longitudeDelta = Math.toRadians(to.longitude - from.longitude)
        val fromLatitude = Math.toRadians(from.latitude)
        val toLatitude = Math.toRadians(to.latitude)
        val a = sin(latitudeDelta / 2) * sin(latitudeDelta / 2) +
            cos(fromLatitude) * cos(toLatitude) * sin(longitudeDelta / 2) * sin(longitudeDelta / 2)
        return EarthRadiusMeters * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private fun distanceToSegmentMeters(point: GeoPoint, start: GeoPoint, end: GeoPoint): Double {
        // GPX segments are short enough that an equirectangular local projection is accurate here.
        val latitudeRadians = Math.toRadians(point.latitude)
        fun projected(location: GeoPoint): Pair<Double, Double> = Pair(
            EarthRadiusMeters * Math.toRadians(location.longitude - point.longitude) * cos(latitudeRadians),
            EarthRadiusMeters * Math.toRadians(location.latitude - point.latitude),
        )
        val (startX, startY) = projected(start)
        val (endX, endY) = projected(end)
        val deltaX = endX - startX
        val deltaY = endY - startY
        val lengthSquared = deltaX * deltaX + deltaY * deltaY
        if (lengthSquared == 0.0) return sqrt(startX * startX + startY * startY)
        val projection = ((-startX * deltaX) + (-startY * deltaY)) / lengthSquared
        val t = projection.coerceIn(0.0, 1.0)
        val closestX = startX + t * deltaX
        val closestY = startY + t * deltaY
        return sqrt(closestX * closestX + closestY * closestY)
    }
}
